import setuptools
setuptools.setup(
    name="python_test",
    version="0.0.1",
    author="Complex",
    author_email="examoke@gmail.com",
    description="A small example package.",
    long_description="A longer example package description.",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)